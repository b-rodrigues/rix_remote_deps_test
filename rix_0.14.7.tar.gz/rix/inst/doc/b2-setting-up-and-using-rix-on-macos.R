## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----include=FALSE------------------------------------------------------------
library(rix)

## ----parsermd-chunk-2, eval = FALSE-------------------------------------------
# install.packages("rix", repos = c(
#   "https://ropensci.r-universe.dev",
#   "https://cloud.r-project.org"
# ))

