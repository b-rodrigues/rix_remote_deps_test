## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval = FALSE-------------------------------------------------------------
# rix(
#   date = ...,
#   r_pkgs = c(...), # whatever packages you need
#   ide = "positron",
#   ...
# )

## ----eval = FALSE-------------------------------------------------------------
# rix(
#   date = ...,
#   r_pkgs = c(...)
#   ide = "none",
#   ...
# )

## ----eval = FALSE-------------------------------------------------------------
# rix(
#   date = ...,
#   r_pkgs = c("languageserver", ...) # languageserver is needed
#   ide = "code", # or "codium"
#   ...
# )

## ----eval = FALSE-------------------------------------------------------------
# rix(
#   date = ...,
#   r_pkgs = c("languageserver", ...) # languageserver is needed
#   ide = "none",
#   ...
# )

## ----eval = FALSE-------------------------------------------------------------
# rix(
#   date = ...,
#   r_pkgs = c(...), # whatever packages you need
#   system_pkgs = "emacs",
#   ...
# )

## ----eval = FALSE-------------------------------------------------------------
# rix(
#   date = ...,
#   r_pkgs = c(...), # whatever packages you need
#   ide = "other",
#   ...
# )

