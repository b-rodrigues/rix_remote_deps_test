## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----include=FALSE------------------------------------------------------------
library(rix)

## ----parsermd-chunk-1, eval = FALSE-------------------------------------------
# rix(
#   r_ver = "latest-upstream",
#   r_pkgs = c("dplyr", "chronicler"),
#   ide = "none"
# )

## ----eval = FALSE-------------------------------------------------------------
# rix(
#   r_ver = "4.4.1",
#   r_pkgs = c("dplyr", "chronicler"),
#   ide = "none"
# )

## ----eval = FALSE-------------------------------------------------------------
# rix(
#   date = "2024-12-14",
#   r_pkgs = c("dplyr", "chronicler"),
#   ide = "none"
# )

