#!/usr/bin/env nix-shell
#!nix-shell default.nix -i bash
positron
