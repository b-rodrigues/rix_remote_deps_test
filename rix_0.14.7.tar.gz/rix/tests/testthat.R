library(testthat)
library(rix)

test_check("rix")
